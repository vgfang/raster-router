dllutl.rb: dynamic import source generator for dll (vorbis, gogo).
lspatch.pl: List the entire instrument configuration
wcc386_w.sh: "OpenWatcom C" wrapper for AutoTools(see doc/*/README.w32)
